import streamlit as st
import threading
import time
import json
import html
from datetime import datetime
import pytz
import pandas as pd
import plotly.graph_objects as go
from bot_engine import (
    BotState, bot_engine, obtener_activos_disponibles,
    validar_licencia, ACTIVOS_PERMITIDOS,
    MIN_SCORE_PREMIUM, VENTANA_ENTRADA_INICIO_SEG, VENTANA_ENTRADA_FIN_SEG,
    RIESGO_AUTO_PCT,
)

ecuador = pytz.timezone("America/Guayaquil")

st.set_page_config(
    page_title="NEUROTRADER PRO - IQ Option Bot",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@400;500;600;700&display=swap');

* { box-sizing: border-box; }

.stApp {
    background: radial-gradient(ellipse at 20% 50%, #0d1b2a 0%, #0a0c15 40%, #060810 100%);
    font-family: 'Rajdhani', sans-serif;
}

section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0d1520 0%, #0a0e1a 100%);
    border-right: 1px solid rgba(0,163,255,0.25);
}

.main-title {
    font-family: 'Orbitron', monospace;
    font-size: 2.2rem;
    font-weight: 900;
    background: linear-gradient(135deg, #00a3ff 0%, #00ffcc 50%, #0066ff 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: 3px;
    margin-bottom: 0;
}

.sub-title {
    font-family: 'Rajdhani', sans-serif;
    color: rgba(0,163,255,0.7);
    font-size: 0.85rem;
    letter-spacing: 4px;
    text-transform: uppercase;
    margin-top: -5px;
}

.card-3d {
    background: linear-gradient(145deg, #1a2035 0%, #0f1628 100%);
    border-radius: 16px;
    padding: 20px;
    margin: 8px 0;
    border: 1px solid rgba(0,163,255,0.2);
    box-shadow: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(0,163,255,0.05), inset 0 1px 0 rgba(255,255,255,0.05);
    position: relative;
    overflow: hidden;
}

.card-3d::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(0,163,255,0.5), transparent);
}

.metric-card {
    background: linear-gradient(145deg, #151d30 0%, #0c1220 100%);
    border-radius: 14px;
    padding: 18px 20px;
    border: 1px solid rgba(0,163,255,0.15);
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    text-align: center;
    position: relative;
    overflow: hidden;
}

.metric-value {
    font-family: 'Orbitron', monospace;
    font-size: 1.8rem;
    font-weight: 700;
    color: #00a3ff;
    line-height: 1;
}

.metric-label {
    font-size: 0.75rem;
    color: rgba(160,180,220,0.7);
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-top: 6px;
    font-family: 'Rajdhani', sans-serif;
}

.metric-green { color: #00ff88; }
.metric-red { color: #ff4b4b; }
.metric-yellow { color: #ffcc00; }
.metric-blue { color: #00a3ff; }

.trade-card {
    border-radius: 12px;
    padding: 14px 18px;
    margin: 6px 0;
    border-left: 4px solid;
    background: linear-gradient(135deg, #13192b 0%, #0d1220 100%);
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}

.trade-win { border-left-color: #00ff88; }
.trade-loss { border-left-color: #ff4b4b; }
.trade-pending { border-left-color: #ffcc00; animation: pulse 2s infinite; }
.trade-return { border-left-color: #888; }

@keyframes pulse {
    0%, 100% { box-shadow: 0 4px 20px rgba(0,0,0,0.3), 0 0 0 0 rgba(255,204,0,0.4); }
    50% { box-shadow: 0 4px 20px rgba(0,0,0,0.3), 0 0 0 8px rgba(255,204,0,0); }
}

.signal-alert {
    background: linear-gradient(135deg, rgba(0,255,136,0.08), rgba(0,163,255,0.08));
    border: 1px solid rgba(0,255,136,0.3);
    border-radius: 14px;
    padding: 18px;
    margin: 10px 0;
    animation: glow 2s infinite;
}

@keyframes glow {
    0%, 100% { box-shadow: 0 0 10px rgba(0,255,136,0.2); }
    50% { box-shadow: 0 0 25px rgba(0,255,136,0.5); }
}

.horario-badge {
    background: rgba(0,255,136,0.1);
    border: 1px solid rgba(0,255,136,0.35);
    border-radius: 8px;
    padding: 6px 12px;
    font-size: 0.78rem;
    color: #00ff88;
    text-align: center;
}

.horario-off {
    background: rgba(255,75,75,0.1);
    border: 1px solid rgba(255,75,75,0.35);
    border-radius: 8px;
    padding: 6px 12px;
    font-size: 0.78rem;
    color: #ff4b4b;
    text-align: center;
}

.log-entry {
    font-family: 'Rajdhani', monospace;
    font-size: 0.82rem;
    padding: 3px 8px;
    border-left: 2px solid;
    margin: 2px 0;
    border-radius: 0 6px 6px 0;
}

.log-WIN { border-color: #00ff88; color: #00ff88; background: rgba(0,255,136,0.05); }
.log-LOSS { border-color: #ff4b4b; color: #ff4b4b; background: rgba(255,75,75,0.05); }
.log-TRADE { border-color: #00a3ff; color: #00a3ff; background: rgba(0,163,255,0.05); }
.log-SIGNAL { border-color: #ffcc00; color: #ffcc00; background: rgba(255,204,0,0.05); }
.log-ERROR { border-color: #ff6666; color: #ff6666; }
.log-WARN { border-color: #ff9900; color: #ff9900; }
.log-INFO { border-color: rgba(100,130,180,0.4); color: rgba(160,185,220,0.85); }

.sidebar-title {
    font-family: 'Orbitron', monospace;
    font-size: 1rem;
    font-weight: 700;
    color: #00a3ff;
    letter-spacing: 2px;
    text-align: center;
    padding: 10px 0;
}

.grid-bg {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background-image:
        linear-gradient(rgba(0,163,255,0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,163,255,0.03) 1px, transparent 1px);
    background-size: 40px 40px;
    pointer-events: none;
    z-index: 0;
}

.stButton > button {
    font-family: 'Rajdhani', sans-serif;
    font-weight: 700;
    letter-spacing: 2px;
    text-transform: uppercase;
    border-radius: 8px;
    border: 1px solid rgba(0,163,255,0.3);
    transition: all 0.3s;
}

div[data-testid="stMetric"] {
    background: linear-gradient(145deg, #151d30 0%, #0c1220 100%);
    border: 1px solid rgba(0,163,255,0.15);
    border-radius: 12px;
    padding: 14px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.3);
}

.asset-chip {
    display: inline-block;
    background: rgba(0,163,255,0.1);
    border: 1px solid rgba(0,163,255,0.2);
    border-radius: 20px;
    padding: 2px 10px;
    font-size: 0.75rem;
    margin: 2px;
    color: rgba(160,200,255,0.85);
}

hr { border-color: rgba(0,163,255,0.15) !important; }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="grid-bg"></div>', unsafe_allow_html=True)

if 'bot_state' not in st.session_state:
    st.session_state.bot_state = BotState()
if 'engine_thread' not in st.session_state:
    st.session_state.engine_thread = None

state: BotState = st.session_state.bot_state


def start_engine():
    t = st.session_state.engine_thread
    if t is None or not t.is_alive():
        st.session_state.engine_thread = threading.Thread(
            target=bot_engine, args=(state,), daemon=True
        )
        st.session_state.engine_thread.start()


def connect_api(email, password):
    try:
        from iqoptionapi.stable_api import IQ_Option
        api = IQ_Option(email, password)
        check, reason = api.connect()
        if check:
            return api, None
        return None, str(reason)
    except Exception as e:
        return None, str(e)


# ─────────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────────
with st.sidebar:
    st.markdown('<div class="sidebar-title">NEUROTRADER PRO</div>', unsafe_allow_html=True)
    st.markdown(
        '<div style="text-align:center;color:rgba(0,163,255,0.5);font-size:0.7rem;'
        'letter-spacing:3px;margin-bottom:15px">IQ OPTION BOT — SOLO REAL</div>',
        unsafe_allow_html=True
    )

    st.markdown("---")
    st.markdown("**CREDENCIALES IQ OPTION**")

    email    = st.text_input("Correo electronico", placeholder="tu@correo.com", key="email_input")
    password = st.text_input("Contrasena", type="password", placeholder="••••••••", key="pass_input")
    licencia = st.text_input("Codigo de licencia", placeholder="XXXX-XXXX", key="lic_input")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("CONECTAR", use_container_width=True, type="primary"):
            if email and password and licencia:
                lic_ok, lic_msg = validar_licencia(licencia, email)
                if not lic_ok:
                    st.error(f"Licencia invalida: {lic_msg}")
                else:
                    st.success(lic_msg, icon="🔑")
                    with st.spinner("Conectando a IQ Option..."):
                        api, err = connect_api(email, password)
                        if api:
                            state.api = api
                            state._email    = email
                            state._password = password
                            state.add_log("Conexion exitosa con IQ Option", "INFO")
                            state.add_log(f"Licencia validada: {lic_msg}", "INFO")
                            activos = obtener_activos_disponibles(api)
                            state.activos_disponibles = activos
                            state.add_log(
                                f"{len(activos)} activos disponibles (mercado REAL)", "INFO"
                            )
                            api.change_balance(state.tipo_cuenta)
                            saldo = api.get_balance()
                            state.saldo = float(saldo) if saldo else 0.0
                            state.saldo_inicial = state.saldo
                            st.rerun()
                        else:
                            st.error(f"Error de conexion: {err}")
            else:
                st.warning("Ingresa correo, contrasena y codigo de licencia")

    with col2:
        if st.button("SALIR", use_container_width=True):
            state.running = False
            state.api = None
            state.add_log("Desconectado", "INFO")
            st.rerun()

    if state.api:
        st.markdown("---")
        st.markdown("**CONFIGURACION**")

        tipo = st.radio(
            "Tipo de cuenta",
            ["PRACTICE", "REAL"],
            horizontal=True,
            index=0 if state.tipo_cuenta == "PRACTICE" else 1
        )
        if tipo != state.tipo_cuenta:
            state.tipo_cuenta = tipo
            if state.api:
                state.api.change_balance(tipo)
                saldo = state.api.get_balance()
                state.saldo = float(saldo) if saldo else 0.0
                state.saldo_inicial = state.saldo
                state.add_log(f"Cuenta {tipo} — Saldo: ${state.saldo:.2f}", "INFO")
                st.rerun()

        st.markdown("**GESTION DE RIESGO**")
        modo_riesgo = st.radio(
            "Modo de riesgo",
            ["Automatico (3% balance)", "Monto Fijo"],
            index=0 if state.modo_riesgo == "automatico" else 1,
            key="modo_riesgo_radio"
        )
        if "Automatico" in modo_riesgo:
            state.modo_riesgo = "automatico"
            monto_auto = max(round(float(state.saldo or 0) * RIESGO_AUTO_PCT, 2), 0.50)
            st.info(f"Monto por operacion: ${monto_auto:.2f} (3% del saldo)")
        else:
            state.modo_riesgo = "fijo"
            monto_fijo = st.number_input(
                "Monto fijo por operacion ($)",
                min_value=0.50,
                max_value=float(max(state.saldo, 10000)),
                value=float(state.monto_fijo),
                step=0.50,
                format="%.2f",
                key="monto_fijo_input"
            )
            state.monto_fijo = monto_fijo
            st.info(f"Monto fijo: ${monto_fijo:.2f} por operacion")

        st.markdown("**ESTRATEGIA ACTIVA**")
        st.success(
            "Premium: S/R Fuerte + EMA50 + 2° Toque + MFM≥55 + Estocástico\n"
            "Máx. 2 ops simultáneas · 1 min expiry"
        )

        st.markdown("---")
        if not state.running:
            if st.button("INICIAR BOT", use_container_width=True, type="primary"):
                state.activos_disponibles = []
                state._ultimo_refresh_activos = 0
                state.running = True
                start_engine()
                state.add_log("Bot iniciado — Mercado REAL", "INFO")
                st.rerun()
        else:
            if st.button("DETENER BOT", use_container_width=True):
                state.running = False
                state.add_log("Bot detenido por el usuario", "INFO")
                st.rerun()

        st.markdown("---")
        saldo_color = "#00ff88" if state.saldo >= state.saldo_inicial else "#ff4b4b"
        profit = state.saldo - state.saldo_inicial
        profit_pct = (profit / state.saldo_inicial * 100) if state.saldo_inicial > 0 else 0
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value" style="color:{saldo_color}">${state.saldo:.2f}</div>
            <div class="metric-label">SALDO {state.tipo_cuenta}</div>
            <div style="font-size:0.8rem;color:{'#00ff88' if profit >= 0 else '#ff4b4b'};margin-top:4px">
                {'&#9650;' if profit >= 0 else '&#9660;'} ${abs(profit):.2f} ({abs(profit_pct):.1f}%)
            </div>
        </div>
        """, unsafe_allow_html=True)


# ─────────────────────────────────────────────
# PANTALLA DE INICIO (SIN CONEXIÓN)
# ─────────────────────────────────────────────
if not state.api:
    st.markdown("""
    <div style="text-align:center;padding:80px 20px">
        <div class="main-title">NEUROTRADER PRO</div>
        <div class="sub-title">Señales Premium — Solo Mercado Real</div>
        <br>
        <div style="background:linear-gradient(135deg,rgba(0,163,255,0.1),rgba(0,100,200,0.05));
            border:1px solid rgba(0,163,255,0.2);border-radius:20px;padding:40px;max-width:640px;margin:0 auto">
            <div style="font-size:4rem;margin-bottom:20px">🤖</div>
            <div style="color:rgba(160,185,220,0.9);font-size:1.05rem;line-height:1.9">
                Ingresa tus credenciales en el panel izquierdo.<br>
                El bot opera <strong style="color:#00a3ff">24/7 en los 14 pares REAL</strong><br>
                con señales de máxima calidad.
                <br><br>
                <span style="color:#00ffcc;font-weight:700">Estrategia Premium:</span><br>
                <span style="font-size:0.9rem;color:rgba(150,200,220,0.75)">
                    Soporte/Resistencia Fuerte · Precio vs EMA50 · Mínimo 2 toques<br>
                    MFM ≥ 55% · Estocástico apoyando · Vencimiento 1 minuto
                </span>
                <br><br>
                <span style="font-size:0.82rem;color:rgba(150,180,220,0.55)">
                    Gestión de riesgo: 3% automático o monto fijo · Máx. 2 ops simultáneas
                </span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    st.stop()


# ─────────────────────────────────────────────
# PANEL PRINCIPAL
# ─────────────────────────────────────────────
st.markdown("""
<div style="padding:8px 0 18px 0">
    <div class="main-title">NEUROTRADER PRO</div>
    <div class="sub-title">Señales Premium — Mercado Real</div>
</div>
""", unsafe_allow_html=True)

ahora = datetime.now(ecuador)
segundo_actual = ahora.second
seg_prox_vela  = 60 - segundo_actual
hora_str       = ahora.strftime('%H:%M:%S')

col_top = st.columns(6)

with col_top[0]:
    estado_txt   = "ACTIVO" if state.running else "DETENIDO"
    estado_color = "#00ff88" if state.running else "#ff4b4b"
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-value" style="font-size:1.2rem;color:{estado_color}">{estado_txt}</div>
        <div class="metric-label">ESTADO</div>
    </div>
    """, unsafe_allow_html=True)

with col_top[1]:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-value metric-blue" style="font-size:1.2rem">{hora_str}</div>
        <div class="metric-label">HORA ECUADOR</div>
    </div>
    """, unsafe_allow_html=True)

with col_top[2]:
    c_color = "#ff4b4b" if seg_prox_vela <= 5 else "#ffcc00" if seg_prox_vela <= 15 else "#00a3ff"
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-value" style="color:{c_color}">{seg_prox_vela}s</div>
        <div class="metric-label">PROXIMA VELA</div>
    </div>
    """, unsafe_allow_html=True)

with col_top[3]:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-value">{state.stats['total']}</div>
        <div class="metric-label">OPS TOTAL</div>
    </div>
    """, unsafe_allow_html=True)

with col_top[4]:
    wr = state.win_rate
    wr_color = "#00ff88" if wr >= 70 else "#ffcc00" if wr >= 55 else "#ff4b4b"
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-value" style="color:{wr_color}">{wr:.1f}%</div>
        <div class="metric-label">WIN RATE</div>
    </div>
    """, unsafe_allow_html=True)

with col_top[5]:
    profit = state.stats['profit']
    p_color = "#00ff88" if profit >= 0 else "#ff4b4b"
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-value" style="color:{p_color}">${profit:+.2f}</div>
        <div class="metric-label">PROFIT</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("---")

col_main, col_side = st.columns([2, 1])

with col_main:
    # Operaciones activas
    if state.active_trades:
        n_act = len(state.active_trades)
        for idx, t in enumerate(state.active_trades):
            dir_color = '#00ff88' if t['direccion'] == 'CALL' else '#ff4b4b'
            dir_icon  = '▲' if t['direccion'] == 'CALL' else '▼'
            slot_tag  = f'<span style="color:rgba(150,180,220,0.5);font-size:0.7rem">[{idx+1}/{n_act}]</span>'
            st.markdown(f"""
            <div class="signal-alert" style="margin-bottom:8px;padding:14px 18px">
                <div style="font-family:'Orbitron',monospace;font-size:0.85rem;color:#ffcc00;margin-bottom:8px;letter-spacing:2px">
                    ⚡ EN CURSO {slot_tag}
                </div>
                <div style="display:flex;gap:18px;flex-wrap:wrap;align-items:center">
                    <div>
                        <div style="color:rgba(150,180,220,0.6);font-size:0.65rem;letter-spacing:1px;margin-bottom:2px">ACTIVO</div>
                        <div style="font-size:1.1rem;font-weight:700;color:#fff">{t['asset']}</div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.6);font-size:0.65rem;letter-spacing:1px;margin-bottom:2px">DIR</div>
                        <div style="font-size:1.2rem;font-weight:900;color:{dir_color}">{dir_icon} {t['direccion']}</div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.6);font-size:0.65rem;letter-spacing:1px;margin-bottom:2px">MONTO</div>
                        <div style="font-size:1.1rem;font-weight:700;color:#00a3ff">${t['monto']:.2f}</div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.6);font-size:0.65rem;letter-spacing:1px;margin-bottom:2px">SCORE</div>
                        <div style="font-size:0.95rem;font-weight:700;color:#ffcc00">{t.get('score', 0)}/100</div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.6);font-size:0.65rem;letter-spacing:1px;margin-bottom:2px">PROB.</div>
                        <div style="font-size:0.95rem;font-weight:700;color:#00ffcc">{t.get('prob', 0):.0%}</div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.6);font-size:0.65rem;letter-spacing:1px;margin-bottom:2px">S/R NIVEL</div>
                        <div style="font-family:monospace;font-size:0.82rem;color:#aaa">
                            {f"{t.get('nivel_sr'):.5f}" if t.get('nivel_sr') else 'N/A'} ({t.get('toques_sr', 0)} toques)
                        </div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.6);font-size:0.65rem;letter-spacing:1px;margin-bottom:2px">ENTRADA → VENCE</div>
                        <div style="font-family:monospace;font-size:0.82rem;color:#aaa">{t['entrada']} → {t['vencimiento']}</div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
    else:
        # Pre-señales en espera
        señales = getattr(state, 'señales_pendientes', [])
        if señales:
            best = max(señales, key=lambda x: x['score'])
            dir_color = '#00ff88' if best['direccion'] == 'CALL' else '#ff4b4b'
            dir_icon  = '▲' if best['direccion'] == 'CALL' else '▼'
            st.markdown(f"""
            <div class="card-3d" style="border-color:rgba(255,204,0,0.35);border-width:2px">
                <div style="color:rgba(150,180,220,0.6);font-size:0.7rem;letter-spacing:2px;margin-bottom:8px">
                    MEJOR SEÑAL EN ESPERA ({len(señales)} candidato(s)) — esperando ventana s58–s02
                </div>
                <div style="display:flex;gap:16px;flex-wrap:wrap;align-items:center">
                    <div>
                        <div style="color:rgba(150,180,220,0.5);font-size:0.68rem">ACTIVO</div>
                        <div style="font-weight:700;color:#fff">{best['asset']}</div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.5);font-size:0.68rem">DIR</div>
                        <div style="font-weight:900;color:{dir_color}">{dir_icon} {best['direccion']}</div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.5);font-size:0.68rem">SCORE</div>
                        <div style="font-weight:700;color:#00a3ff">{best['score']}/100</div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.5);font-size:0.68rem">PROB.</div>
                        <div style="font-weight:700;color:#00ffcc">{best['prob']:.0%}</div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.5);font-size:0.68rem">S/R TOQUES</div>
                        <div style="font-weight:700;color:#ffcc00">{best.get('toques_sr', 0)} toques</div>
                    </div>
                    <div>
                        <div style="color:rgba(150,180,220,0.5);font-size:0.68rem">ESTRATEGIA</div>
                        <div style="font-weight:600;color:#ffcc00">S/R Premium</div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)
        else:
            prog = ""
            if state.running and state.scan_total > 0:
                pct = int(state.scan_progreso / state.scan_total * 100)
                prog = f"""
                <div style="margin-top:8px">
                    <div style="display:flex;justify-content:space-between;font-size:0.75rem;
                        color:rgba(150,180,220,0.5);margin-bottom:3px">
                        <span>Escaneando activos</span>
                        <span>{state.scan_progreso}/{state.scan_total}</span>
                    </div>
                    <div style="background:rgba(20,30,50,0.8);border-radius:4px;height:4px">
                        <div style="width:{pct}%;height:100%;background:#00a3ff;border-radius:4px;
                            box-shadow:0 0 8px rgba(0,163,255,0.5)"></div>
                    </div>
                </div>"""
            if state.running:
                msg = "Analizando señales premium... Escaneo cada 5 segundos."
            else:
                msg = "Bot detenido. Presiona INICIAR BOT para comenzar."
            st.markdown(f"""
            <div class="card-3d">
                <div style="color:rgba(150,180,220,0.65);font-size:0.9rem">{msg}</div>
                {prog}
            </div>
            """, unsafe_allow_html=True)

    # Historial
    st.markdown("#### Historial de Operaciones")
    if state.trades:
        for trade in reversed(state.trades[-15:]):
            estado_t = trade.get('estado', 'PENDIENTE')
            if estado_t == 'GANADA':
                cls = 'trade-win'
                ganancia_str = f"+${trade.get('ganancia', 0):.2f}"
                g_color = '#00ff88'
                icon = 'WIN'
            elif estado_t == 'PERDIDA':
                cls = 'trade-loss'
                ganancia_str = f"-${trade['monto']:.2f}"
                g_color = '#ff4b4b'
                icon = 'LOSS'
            elif estado_t == 'DEVUELTA':
                cls = 'trade-return'
                ganancia_str = '$0.00'
                g_color = '#888'
                icon = 'DEV'
            else:
                cls = 'trade-pending'
                ganancia_str = 'Pendiente'
                g_color = '#ffcc00'
                icon = '...'

            dir_color = '#00ff88' if trade['direccion'] == 'CALL' else '#ff4b4b'
            dir_icon  = '▲' if trade['direccion'] == 'CALL' else '▼'
            nivel_sr_str = (
                f"{trade.get('nivel_sr'):.5f}" if trade.get('nivel_sr') else "—"
            )
            st.markdown(f"""
            <div class="trade-card {cls}">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <span style="font-weight:700;color:#fff;font-size:1rem">{trade['asset']}</span>
                        <span style="color:{dir_color};margin-left:10px;font-weight:700">{dir_icon} {trade['direccion']}</span>
                        <span style="color:rgba(150,180,220,0.5);font-size:0.8rem;margin-left:8px">${trade['monto']:.2f}</span>
                        <span style="color:#ffcc00;font-size:0.75rem;margin-left:8px">score={trade.get('score',0)}</span>
                    </div>
                    <div style="text-align:right">
                        <span style="color:{g_color};font-family:'Orbitron',monospace;font-size:0.9rem;font-weight:700">{ganancia_str}</span>
                        <span style="color:rgba(150,180,220,0.4);font-size:0.7rem;margin-left:8px">[{icon}]</span>
                    </div>
                </div>
                <div style="margin-top:4px;color:rgba(150,180,220,0.5);font-size:0.78rem">
                    S/R Premium · nivel={nivel_sr_str} · {trade.get('toques_sr',0)} toques &nbsp;·&nbsp;
                    {trade['entrada']} → {trade['vencimiento']}
                </div>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="card-3d" style="text-align:center;color:rgba(150,180,220,0.35);padding:30px">
            El historial de operaciones aparecera aqui
        </div>
        """, unsafe_allow_html=True)


with col_side:
    st.markdown("#### Estadisticas")

    ganadas   = state.stats['ganadas']
    perdidas  = state.stats['perdidas']
    devueltas = state.stats['devueltas']
    total     = ganadas + perdidas + devueltas

    c1, c2 = st.columns(2)
    with c1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value metric-green" style="font-size:1.5rem">{ganadas}</div>
            <div class="metric-label">GANADAS</div>
        </div>
        """, unsafe_allow_html=True)
    with c2:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-value metric-red" style="font-size:1.5rem">{perdidas}</div>
            <div class="metric-label">PERDIDAS</div>
        </div>
        """, unsafe_allow_html=True)

    if total > 0:
        fig_donut = go.Figure(data=[go.Pie(
            labels=['Ganadas', 'Perdidas', 'Devueltas'],
            values=[max(ganadas, 0.01), max(perdidas, 0.01), max(devueltas, 0.01)],
            hole=0.65,
            marker=dict(
                colors=['#00ff88', '#ff4b4b', '#888888'],
                line=dict(color='#0a0c15', width=2)
            ),
            textinfo='none',
            hovertemplate='%{label}: %{value}<br>%{percent}<extra></extra>',
        )])
        fig_donut.update_layout(
            showlegend=False,
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            margin=dict(l=10, r=10, t=10, b=10),
            height=180,
            annotations=[dict(
                text=f"<b>{state.win_rate:.0f}%</b>",
                x=0.5, y=0.5,
                font=dict(size=22, color='#00a3ff', family='Orbitron'),
                showarrow=False
            )]
        )
        st.plotly_chart(fig_donut, use_container_width=True, config={'displayModeBar': False})

    # Info estrategia
    st.markdown("#### Estrategia Premium")
    st.markdown("""
    <div style="background:rgba(0,163,255,0.07);border:1px solid rgba(0,163,255,0.2);
        border-radius:10px;padding:12px;font-size:0.78rem;color:rgba(160,195,230,0.85);line-height:1.7">
        <div style="color:#00ffcc;font-weight:700;margin-bottom:4px">CALL (Compra)</div>
        · Soporte Fuerte (≥2 toques)<br>
        · Precio > EMA50 M5<br>
        · MFM ≥ 55% alcista<br>
        · Estocástico ≤ 30 (rebote)<br><br>
        <div style="color:#ff4b4b;font-weight:700;margin-bottom:4px">PUT (Venta)</div>
        · Resistencia Fuerte (≥2 toques)<br>
        · Precio &lt; EMA50 M5<br>
        · MFM ≥ 55% bajista<br>
        · Estocástico ≥ 70 (caída)
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown(f"""
    <div style="font-size:0.75rem;color:rgba(150,180,220,0.55);text-align:center">
        Activos: <span style="color:#00a3ff;font-weight:700">{len(state.activos_disponibles)}</span> disponibles
        &nbsp;|&nbsp; Score mín: <span style="color:#ffcc00">{MIN_SCORE_PREMIUM}</span>
        &nbsp;|&nbsp; Entrada: <span style="color:#00ffcc">s{VENTANA_ENTRADA_INICIO_SEG}–s{VENTANA_ENTRADA_FIN_SEG}</span>
    </div>
    """, unsafe_allow_html=True)


# ─────────────────────────────────────────────
# GRAFICAS Y LOGS
# ─────────────────────────────────────────────
st.markdown("---")
col_chart, col_log = st.columns([3, 2])

with col_chart:
    st.markdown("#### Curva de Profit Acumulado")
    if state.trades:
        profits_acum = []
        acum = 0.0
        for t in state.trades:
            if t['estado'] == 'GANADA':
                acum += t.get('ganancia', 0)
            elif t['estado'] == 'PERDIDA':
                acum -= t['monto']
            profits_acum.append(acum)

        colors_curve = ['#00ff88' if v >= 0 else '#ff4b4b' for v in profits_acum]

        fig_profit = go.Figure()
        fig_profit.add_trace(go.Scatter(
            x=list(range(len(profits_acum))),
            y=profits_acum,
            mode='lines+markers',
            line=dict(color='#00a3ff', width=2.5),
            marker=dict(color=colors_curve, size=7, line=dict(color='#0a0c15', width=1.5)),
            fill='tozeroy',
            fillcolor='rgba(0,163,255,0.07)',
            hovertemplate='Operacion #%{x}<br>Profit: $%{y:.2f}<extra></extra>',
        ))
        fig_profit.add_hline(y=0, line_dash='dash', line_color='rgba(150,150,150,0.3)')
        fig_profit.update_layout(
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(10,15,25,0.5)',
            margin=dict(l=10, r=10, t=10, b=10),
            height=230,
            xaxis=dict(showgrid=False, color='rgba(150,180,220,0.4)', title=''),
            yaxis=dict(showgrid=True, gridcolor='rgba(0,163,255,0.08)',
                       color='rgba(150,180,220,0.4)', title='USD'),
            font=dict(family='Rajdhani', color='rgba(150,180,220,0.7)'),
        )
        st.plotly_chart(fig_profit, use_container_width=True, config={'displayModeBar': False})
    else:
        st.markdown("""
        <div class="card-3d" style="height:200px;display:flex;align-items:center;justify-content:center;
            color:rgba(150,180,220,0.3)">
            La curva de profit aparecera con las primeras operaciones
        </div>
        """, unsafe_allow_html=True)

with col_log:
    st.markdown("#### Log en Vivo")
    logs_recientes = list(reversed(state.logs[-40:]))
    log_html = ""
    for entry in logs_recientes:
        nivel = entry.get('nivel', 'INFO')
        msg   = html.escape(entry['msg'])
        t_str = entry['time']
        log_html += (
            f'<div class="log-entry log-{nivel}">'
            f'<span style="opacity:0.45">{t_str}</span> {msg}</div>\n'
        )
    st.markdown(f"""
    <div style="background:rgba(8,12,22,0.85);border:1px solid rgba(0,163,255,0.12);
        border-radius:12px;padding:12px;height:260px;overflow-y:auto;
        font-size:0.82rem;line-height:1.5">
        {log_html if log_html else '<div style="color:rgba(150,180,220,0.3);text-align:center;padding:40px">Los logs apareceran aqui...</div>'}
    </div>
    """, unsafe_allow_html=True)

    # Panel de diagnóstico
    diag = getattr(state, 'diagnostico', {})
    eventos = list(reversed(diag.get('eventos', [])[-12:]))
    mejor   = diag.get('mejor_candidato') or {}

    def safe_txt(value):
        return html.escape(str(value if value is not None else "—"))

    mejor_html = (
        f"<span style='color:#fff;font-weight:700'>{safe_txt(mejor.get('asset'))}</span> "
        f"<span style='color:{'#00ff88' if mejor.get('direccion') == 'CALL' else '#ff4b4b'};font-weight:700'>"
        f"{safe_txt(mejor.get('direccion'))}</span> "
        f"<span style='color:#00a3ff'>score {safe_txt(mejor.get('score'))}</span> "
        f"<span style='color:#00ffcc'>prob {float(mejor.get('prob', 0)):.0%}</span>"
        if mejor else
        "<span style='color:rgba(150,180,220,0.4)'>Sin candidato todavía</span>"
    )

    eventos_html = ""
    for ev in eventos:
        tipo_ev = ev.get('tipo', 'INFO')
        color_ev = {
            'SIGNAL': '#ffcc00',
            'TRADE': '#00ff88',
            'WARN': '#ff9900',
            'ERROR': '#ff4b4b',
            'BLOCK': '#ff6666',
        }.get(tipo_ev, 'rgba(160,185,220,0.85)')
        eventos_html += (
            f"<div style='border-left:2px solid {color_ev};padding:3px 7px;margin:3px 0;"
            f"background:rgba(255,255,255,0.025);border-radius:0 6px 6px 0'>"
            f"<span style='opacity:.45'>{safe_txt(ev.get('time'))}</span> "
            f"<span style='color:{color_ev};font-size:.7rem;font-weight:700'>{safe_txt(tipo_ev)}</span> "
            f"{html.escape(str(ev.get('msg', '')))}</div>"
        )

    # Construir tabla de análisis por activo
    ultimo_analisis = diag.get('ultimo_analisis', {})
    analisis_html = ""
    if ultimo_analisis:
        for asset_k, motivo_v in sorted(ultimo_analisis.items()):
            es_ok = str(motivo_v).startswith("✅")
            color = "#00ff88" if es_ok else "rgba(160,185,220,0.6)"
            bg    = "rgba(0,255,136,0.04)" if es_ok else "transparent"
            analisis_html += (
                f"<div style='display:flex;gap:8px;padding:2px 4px;background:{bg};border-radius:4px;margin:1px 0'>"
                f"<span style='color:#00a3ff;font-weight:700;min-width:70px'>{html.escape(asset_k)}</span>"
                f"<span style='color:{color};font-size:0.76rem'>{html.escape(str(motivo_v))}</span>"
                f"</div>"
            )

    st.markdown(f"""
    <div style="margin-top:12px;background:rgba(8,12,22,0.9);border:1px solid rgba(255,204,0,0.18);
        border-radius:12px;padding:12px;font-size:0.78rem;line-height:1.45">
        <div style="color:#ffcc00;font-family:Orbitron,monospace;font-weight:700;letter-spacing:1px;margin-bottom:8px">
            PANEL DE DIAGNOSTICO
        </div>
        <div style="display:grid;grid-template-columns:1fr;gap:7px;margin-bottom:8px">
            <div><span style="color:rgba(150,180,220,.5)">Estado:</span> {safe_txt(diag.get('estado', '—'))}</div>
            <div><span style="color:rgba(150,180,220,.5)">Ultimo escaneo:</span> {safe_txt(diag.get('ultimo_lote', '—'))}</div>
            <div><span style="color:rgba(150,180,220,.5)">Mejor señal:</span> {mejor_html}</div>
            <div><span style="color:rgba(150,180,220,.5)">Ultima ejecucion:</span> <span style="color:#00ff88">{safe_txt(diag.get('ultima_ejecucion', '—'))}</span></div>
        </div>
        {"<div style='color:#ffcc00;font-size:0.72rem;font-weight:700;margin-bottom:4px;letter-spacing:1px'>ANÁLISIS POR ACTIVO (último ciclo):</div>" + '<div style="max-height:130px;overflow-y:auto">' + analisis_html + '</div>' if analisis_html else '<div style="color:rgba(150,180,220,.35);text-align:center;padding:10px">El análisis por activo aparecerá cuando el scanner inicie.</div>'}
    </div>
    """, unsafe_allow_html=True)


# Activos disponibles
if state.activos_disponibles:
    with st.expander(f"Activos disponibles ({len(state.activos_disponibles)})", expanded=False):
        chips_html = "".join(f'<span class="asset-chip">{a}</span>' for a in state.activos_disponibles)
        st.markdown(f'<div style="line-height:2">{chips_html}</div>', unsafe_allow_html=True)
elif state.api:
    with st.expander(f"Activos configurados ({len(ACTIVOS_PERMITIDOS)})", expanded=False):
        chips_html = "".join(
            f'<span class="asset-chip">{a}</span>'
            for a in sorted(ACTIVOS_PERMITIDOS)
        )
        st.markdown(f'<div style="line-height:2">{chips_html}</div>', unsafe_allow_html=True)

if state.running:
    time.sleep(1)
    st.rerun()
