# NeuroTrader Pro — VPS Setup

## Instalar
pip install -r requirements.txt
pip install git+https://github.com/iqoptionapi/iqoptionapi.git

## Ejecutar
streamlit run main.py --server.port 5000 --server.address 0.0.0.0

## Configuración v2 (señales optimizadas)
- Estrategia: S/R Premium + EMA50 + MFI(0-100) + Estocástico
- MFI >= 52 para CALL | MFI <= 48 para PUT (Money Flow Index correcto)
- Estocástico: CALL <= 40 | PUT >= 60 (zona ampliada)
- Score mínimo: 60 (bajado de 70)
- Zona S/R: tolerancia ATR x3.0 (ampliada)
- Mercado: Solo REAL (14 pares)
- Horario: 24/7 sin restricción
- Vencimiento: 1 minuto
- Riesgo: 3% automático o monto fijo
- Max 2 ops simultáneas si scores similares
- Ventana de entrada: segundos 58-02
- Log muestra motivo exacto de descarte por activo cada ciclo
